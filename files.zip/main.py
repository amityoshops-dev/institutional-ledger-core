"""
Complete, runnable FastAPI app wiring together:
- parser_corrected.py (handles batched camt.054 entries)
- DistributedIdempotencyGuard (idempotency_and_engine_fixes.py logic, inlined here)
- MultiTierReconciliationEngine (Tier 1/2/3 recon, verified balanced by hand earlier)

Fix applied here that wasn't in the original draft: the idempotency key computed
for Redis is now the SAME string written to journal_entries.idempotency_key in
Postgres, so a Redis outage doesn't silently reopen the double-credit window.
"""
import uuid
import hashlib
import hmac
from decimal import Decimal
from typing import Dict, Any, Optional

from fastapi import FastAPI, Header, HTTPException, Request, Response, status
import redis.asyncio as aioredis
import asyncpg
import structlog
from opentelemetry import trace

from parser_corrected import PaymentIngestionNormalizer, NormalizedTransaction

logger = structlog.get_logger()
tracer = trace.get_tracer("recon-engine")

app = FastAPI(title="Institutional Virtual Account Ledger Core", version="1.0.1")

db_pool: Optional[asyncpg.Pool] = None
redis_client: Optional[aioredis.Redis] = None

DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/ledger_db"
REDIS_URL = "redis://localhost:6379"
HMAC_SECRET = "PROD_SECRET_KEY"  # replace with a real secret pulled from env/secrets manager

IDEMPOTENCY_LUA = """
if redis.call("EXISTS", KEYS[1]) == 1 then
    return 0
else
    redis.call("SET", KEYS[1], ARGV[1], "EX", ARGV[2])
    return 1
end
"""


class DistributedIdempotencyGuard:
    def __init__(self, redis_conn: aioredis.Redis, ttl_seconds: int = 86400):
        self.redis = redis_conn
        self.ttl = ttl_seconds
        self._script = self.redis.register_script(IDEMPOTENCY_LUA)

    def generate_key(self, tenant_id: str, utr: str, amount: Decimal, currency: str) -> str:
        formatted_amount = f"{amount:.4f}"
        return f"idemp:{tenant_id}:{utr.strip()}:{formatted_amount}:{currency.upper()}"

    async def acquire_lock(self, idempotency_key: str, payload_hash: str) -> bool:
        result = await self._script(keys=[idempotency_key], args=[payload_hash, self.ttl])
        return result == 1


idempotency_guard: Optional[DistributedIdempotencyGuard] = None


class MultiTierReconciliationEngine:
    def __init__(self, pool: asyncpg.Pool):
        self.db = pool

    async def execute_settlement(self, tx: NormalizedTransaction, idemp_key: str) -> Dict[str, Any]:
        with tracer.start_as_current_span("execute_reconciliation_and_ledger"):
            async with self.db.acquire() as conn:
                async with conn.transaction():
                    nostro = await conn.fetchrow(
                        "SELECT account_id FROM chart_of_accounts WHERE tenant_id = $1 AND classification = 'NOSTRO_CLEARING'",
                        tx.tenant_id,
                    )
                    van_acct = await conn.fetchrow(
                        "SELECT account_id FROM chart_of_accounts WHERE tenant_id = $1 AND account_number = $2",
                        tx.tenant_id, tx.van,
                    )
                    fee_suspense = await conn.fetchrow(
                        "SELECT account_id FROM chart_of_accounts WHERE tenant_id = $1 AND classification = 'FEE_SUSPENSE'",
                        tx.tenant_id,
                    )
                    break_suspense = await conn.fetchrow(
                        "SELECT account_id FROM chart_of_accounts WHERE tenant_id = $1 AND classification = 'BREAK_SUSPENSE'",
                        tx.tenant_id,
                    )
                    if not nostro or not fee_suspense or not break_suspense:
                        raise RuntimeError(
                            f"Tenant {tx.tenant_id} is missing required control accounts "
                            f"(NOSTRO_CLEARING/FEE_SUSPENSE/BREAK_SUSPENSE) in chart_of_accounts"
                        )

                    invoice = await conn.fetchrow(
                        """
                        SELECT invoice_id, expected_amount, status
                        FROM invoices
                        WHERE tenant_id = $1 AND assigned_van = $2 AND status = 'PENDING'
                        FOR UPDATE
                        """,
                        tx.tenant_id, tx.van,
                    )

                    entry_id = uuid.uuid4()
                    journal_lines = []

                    if not van_acct or not invoice:
                        recon_status = "SUSPENSE_BREAK"
                        journal_lines.append((entry_id, nostro["account_id"], "DEBIT", tx.amount, 1))
                        journal_lines.append((entry_id, break_suspense["account_id"], "CREDIT", tx.amount, 2))
                    else:
                        expected_amt = Decimal(str(invoice["expected_amount"]))
                        variance = expected_amt - tx.amount

                        if variance == Decimal("0.0000"):
                            recon_status = "MATCHED_EXACT"
                            journal_lines.append((entry_id, nostro["account_id"], "DEBIT", tx.amount, 1))
                            journal_lines.append((entry_id, van_acct["account_id"], "CREDIT", tx.amount, 2))
                            await conn.execute("UPDATE invoices SET status = 'PAID' WHERE invoice_id = $1", invoice["invoice_id"])

                        elif Decimal("0.0000") < variance <= Decimal("50.0000"):
                            recon_status = "TOLERANCE_ADJUSTED"
                            journal_lines.append((entry_id, nostro["account_id"], "DEBIT", tx.amount, 1))
                            journal_lines.append((entry_id, fee_suspense["account_id"], "DEBIT", variance, 2))
                            journal_lines.append((entry_id, van_acct["account_id"], "CREDIT", expected_amt, 3))
                            await conn.execute("UPDATE invoices SET status = 'PAID' WHERE invoice_id = $1", invoice["invoice_id"])

                        else:
                            recon_status = "SUSPENSE_BREAK"
                            journal_lines.append((entry_id, nostro["account_id"], "DEBIT", tx.amount, 1))
                            journal_lines.append((entry_id, break_suspense["account_id"], "CREDIT", tx.amount, 2))

                    # FIX applied: idemp_key (not tx.message_id) goes into idempotency_key column
                    await conn.execute(
                        """
                        INSERT INTO journal_entries (
                            entry_id, tenant_id, idempotency_key, utr_reference, message_id,
                            event_time, status, reconciliation_state, description
                        ) VALUES ($1, $2, $3, $4, $5, $6, 'POSTED', $7, $8)
                        """,
                        entry_id, tx.tenant_id, idemp_key, tx.utr, tx.message_id,
                        tx.event_timestamp, recon_status, f"Source: {tx.raw_format}",
                    )

                    await conn.executemany(
                        """
                        INSERT INTO journal_lines (entry_id, account_id, direction, amount, sequence_no)
                        VALUES ($1, $2, $3, $4, $5)
                        """,
                        journal_lines,
                    )

                    logger.info(
                        "transaction_settled",
                        entry_id=str(entry_id),
                        utr=tx.utr,
                        recon_status=recon_status,
                        amount=float(tx.amount),
                    )

                    return {
                        "entry_id": str(entry_id),
                        "utr": tx.utr,
                        "recon_status": recon_status,
                        "lines_posted": len(journal_lines),
                    }


recon_engine: Optional[MultiTierReconciliationEngine] = None


@app.on_event("startup")
async def startup_event():
    global db_pool, redis_client, idempotency_guard, recon_engine
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    redis_client = aioredis.from_url(REDIS_URL, decode_responses=False)
    idempotency_guard = DistributedIdempotencyGuard(redis_client)
    recon_engine = MultiTierReconciliationEngine(db_pool)
    logger.info("startup_complete")


@app.on_event("shutdown")
async def shutdown_event():
    if db_pool:
        await db_pool.close()
    if redis_client:
        await redis_client.close()


@app.get("/health")
async def health():
    return {"status": "ok"}


def verify_hmac_signature(payload: bytes, signature: str, secret: str = HMAC_SECRET):
    expected_sig = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected_sig, signature):
        raise HTTPException(status_code=401, detail="Invalid cryptographic HMAC signature")


@app.post("/v1/webhooks/clearing/iso20022", status_code=status.HTTP_200_OK)
async def ingest_iso20022_webhook(
    request: Request,
    x_tenant_id: str = Header(..., alias="X-Tenant-ID"),
    x_signature_sha256: str = Header(..., alias="X-Signature-SHA256"),
):
    raw_body = await request.body()
    verify_hmac_signature(raw_body, x_signature_sha256)

    try:
        transactions = PaymentIngestionNormalizer.parse_iso20022_camt054(raw_body.decode("utf-8"), x_tenant_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Malformed ISO 20022 XML: {str(e)}")

    results = []
    for tx in transactions:  # loops over EVERY entry — fixes the batch-drop bug
        idemp_key = idempotency_guard.generate_key(tx.tenant_id, tx.utr, tx.amount, tx.currency)
        lock_acquired = await idempotency_guard.acquire_lock(idemp_key, tx.message_id)

        if not lock_acquired:
            results.append({"utr": tx.utr, "status": "ALREADY_PROCESSED_OR_IN_FLIGHT"})
            continue

        try:
            result = await recon_engine.execute_settlement(tx, idemp_key)
            results.append(result)
        except Exception as e:
            await redis_client.delete(idemp_key)
            raise HTTPException(status_code=500, detail=f"Ledger Commit Error: {str(e)}")

    return {"processed": len(results), "results": results}
